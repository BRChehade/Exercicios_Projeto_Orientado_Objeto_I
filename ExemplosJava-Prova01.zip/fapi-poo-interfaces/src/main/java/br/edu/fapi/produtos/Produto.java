package br.edu.fapi.produtos;

public interface Produto {

	void setPreco(double preco);
	
	double getPreco();
	
}
