package br.edu.fapi.produtos;

public interface PromocaoMelhorIdade extends Promocao {

	double promocaoAdicional(double descontoAdicional);

}
