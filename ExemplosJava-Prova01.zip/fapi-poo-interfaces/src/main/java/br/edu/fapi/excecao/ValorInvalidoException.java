package br.edu.fapi.excecao;

public class ValorInvalidoException extends Exception{
	

	
	
}
