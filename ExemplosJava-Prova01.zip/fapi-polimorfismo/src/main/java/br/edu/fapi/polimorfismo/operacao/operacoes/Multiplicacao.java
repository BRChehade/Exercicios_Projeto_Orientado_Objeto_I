package br.edu.fapi.polimorfismo.operacao.operacoes;

import br.edu.fapi.polimorfismo.operacao.Operacao;

public class Multiplicacao extends Operacao{
	
	public float executaOperacao(float numero1, float numero2) {
		return numero1 * numero2;
	}
}
