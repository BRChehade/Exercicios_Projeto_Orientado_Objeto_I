package br.edu.fapi.polimorfismo.operacao;

public class Operacao {

	public float executaOperacao(float numero1, float numero2){
		return 0.0F;
	}
	
}
