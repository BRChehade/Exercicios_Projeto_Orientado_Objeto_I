package Redacao;

public class RedacaoCritica extends ModeloRedacao {

	@Override
	public void preencheConteudo(Redacao redacao) {
		redacao.setConteudo("Redacao critica sendo escrita");

	}

}
