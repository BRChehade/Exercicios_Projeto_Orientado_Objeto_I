package Redacao;

public class Redacao {

	
	private String cabecalho;
	private String conteudo;
	private String rodape;
	
	public String getCabecalho() {
		return cabecalho;
	}
	public void setCabecalho(String cabecalho) {
		this.cabecalho = cabecalho;
	}
	public String getConteudo() {
		return conteudo;
	}
	public void setConteudo(String conteudo) {
		this.conteudo = conteudo;
	}
	public String getRodape() {
		return rodape;
	}
	public void setRodape(String rodape) {
		this.rodape = rodape;
	}
	
}
