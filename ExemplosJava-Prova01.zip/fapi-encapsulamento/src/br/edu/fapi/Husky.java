package br.edu.fapi;

public class Husky {

}
