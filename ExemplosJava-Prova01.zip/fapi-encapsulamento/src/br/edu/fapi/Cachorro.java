package br.edu.fapi;

public abstract class Cachorro {

}
