package br.edu.fapi.heranca.exemplo.permissionamento;

public class Administrador extends Usuario{

}
