package br.edu.fapi.heranca.main;

import br.edu.fapi.heranca.A;
import br.edu.fapi.pacote2.Super;

public class MainExemploMatheus {

	public static void main(String[] args) {
		Super exemplo = new A();

		exemplo.tirarFotocopias(100);
		
	}

}
