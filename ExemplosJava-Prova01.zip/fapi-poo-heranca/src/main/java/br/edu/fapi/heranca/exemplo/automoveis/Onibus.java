package br.edu.fapi.heranca.exemplo.automoveis;

public class Onibus extends Automovel{

}
