package br.edu.fapi.heranca;

import br.edu.fapi.pacote2.Super;

public class A extends Super{

	public A() {
		super.preco = 0.90;
	}
	
}
