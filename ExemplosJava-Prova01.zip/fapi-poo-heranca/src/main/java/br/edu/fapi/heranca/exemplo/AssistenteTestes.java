package br.edu.fapi.heranca.exemplo;

public class AssistenteTestes extends Funcionario {

	public void falarProfissao() {
		System.out.println("Minha profissão é assistente de testes :)");
	}
	
}
