package br.edu.fapi.heranca.exemplo;

public class Professor extends Funcionario{

	public void falarProfissao() {
		System.out.println("Minha profissão é Professor :)");
	}
	
}
