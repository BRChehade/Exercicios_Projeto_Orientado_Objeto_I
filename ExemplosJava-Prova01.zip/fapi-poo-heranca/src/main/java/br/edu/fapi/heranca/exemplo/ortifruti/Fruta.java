package br.edu.fapi.heranca.exemplo.ortifruti;

public class Fruta {

}
