package br.edu.fapi.heranca.exemplo.automoveis;

public class Carro extends Automovel{

	private String categoria;

	public String getCategoria() {
		return categoria;
	}

	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}
	
}
