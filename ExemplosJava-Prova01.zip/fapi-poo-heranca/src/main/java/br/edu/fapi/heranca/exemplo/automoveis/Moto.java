package br.edu.fapi.heranca.exemplo.automoveis;

public class Moto extends Automovel{

	private int cilindrada;

	public int getCilindrada() {
		return cilindrada;
	}

	public void setCilindrada(int cilindrada) {
		this.cilindrada = cilindrada;
	}
	
	
}
