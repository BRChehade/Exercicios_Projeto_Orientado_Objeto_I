package br.edu.fapi.heranca.exemplo;

public class TecnicoInformatica extends Funcionario {

	public void falarProfissao() {
		System.out.println("Minha profissão é técnico em informática :)");
	}
	
}
