package br.edu.fapi.poo;

public class CriacaoAlunos {

	public static void main(String[] args) {
		Aluno aluno1 = new Aluno();
		aluno1.setNome("Matheus");
		System.out.println(aluno1);
		Aluno aluno2 = new Aluno();
		aluno2.setNome("Robson");
		System.out.println(aluno2);
		
		Aluno aluno3 = new Aluno();
		Aluno aluno4 = new Aluno();
		Aluno aluno5 = new Aluno();
	}

}

