package br.edu.fapi.poo;

public class ConstructorExample {

	public static void main(String[] args) {
			Aluno aluno = new Aluno();
			aluno.setNome("Matheus");
			System.out.println(aluno.getNome());

	}

}
